import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { OrdersAPI } from "../api/client";

export default function OrdersPage() {
  const queryClient = useQueryClient();

  const { data: orders, isLoading, error } = useQuery({
    queryKey: ["orders"],
    queryFn: () => OrdersAPI.list({ limit: 100 }),
  });

  const syncMutation = useMutation({
    mutationFn: () => OrdersAPI.sync(),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["orders"] }),
  });

  if (isLoading) return <p>Loading orders…</p>;
  if (error) return <p className="error">Failed to load orders: {error.message}</p>;

  return (
    <div>
      <div className="page-toolbar">
        <h2>Sales Orders</h2>
        <button onClick={() => syncMutation.mutate()} disabled={syncMutation.isPending}>
          {syncMutation.isPending ? "Syncing from SAP…" : "Sync from SAP"}
        </button>
      </div>

      <table className="data-table">
        <thead>
          <tr>
            <th>Order #</th>
            <th>Customer</th>
            <th>Status</th>
            <th>Order Date</th>
            <th>Total</th>
            <th>Last Synced</th>
          </tr>
        </thead>
        <tbody>
          {orders?.map((o) => (
            <tr key={o.id}>
              <td>{o.sap_order_number}</td>
              <td>{o.customer_name || o.customer_id}</td>
              <td>
                <span className={`status-badge status-${o.status.toLowerCase()}`}>{o.status}</span>
              </td>
              <td>{new Date(o.order_date).toLocaleDateString()}</td>
              <td>
                {o.total_value ? `${o.total_value} ${o.currency}` : "—"}
              </td>
              <td>{o.last_synced_at ? new Date(o.last_synced_at).toLocaleString() : "Never"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
