import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { InventoryAPI } from "../api/client";

export default function InventoryPage() {
  const queryClient = useQueryClient();

  const { data: items, isLoading, error } = useQuery({
    queryKey: ["inventory"],
    queryFn: () => InventoryAPI.list({ limit: 200 }),
  });

  const syncMutation = useMutation({
    mutationFn: () => InventoryAPI.sync(),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["inventory"] }),
  });

  if (isLoading) return <p>Loading inventory…</p>;
  if (error) return <p className="error">Failed to load inventory: {error.message}</p>;

  return (
    <div>
      <div className="page-toolbar">
        <h2>Inventory</h2>
        <button onClick={() => syncMutation.mutate()} disabled={syncMutation.isPending}>
          {syncMutation.isPending ? "Syncing from SAP…" : "Sync from SAP"}
        </button>
      </div>

      <table className="data-table">
        <thead>
          <tr>
            <th>Material #</th>
            <th>Description</th>
            <th>Plant</th>
            <th>On Hand</th>
            <th>Reserved</th>
            <th>Available</th>
            <th>UoM</th>
          </tr>
        </thead>
        <tbody>
          {items?.map((i) => (
            <tr key={i.id}>
              <td>{i.material_number}</td>
              <td>{i.description || "—"}</td>
              <td>{i.plant}</td>
              <td>{i.quantity_on_hand}</td>
              <td>{i.quantity_reserved}</td>
              <td>{(Number(i.quantity_on_hand) - Number(i.quantity_reserved)).toFixed(2)}</td>
              <td>{i.unit_of_measure || "—"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
