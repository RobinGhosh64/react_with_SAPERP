import axios from "axios";

// In production, VITE_API_BASE_URL points at the ALB / API Gateway URL.
// In dev, Vite proxies /api to the local FastAPI server (see vite.config.js).
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "/api/v1";

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: { "Content-Type": "application/json" },
});

export const OrdersAPI = {
  list: (params) => apiClient.get("/orders", { params }).then((r) => r.data),
  get: (id) => apiClient.get(`/orders/${id}`).then((r) => r.data),
  create: (payload) => apiClient.post("/orders", payload).then((r) => r.data),
  sync: (changed_since) =>
    apiClient.post("/orders/sync", null, { params: { changed_since } }).then((r) => r.data),
};

export const InventoryAPI = {
  list: (params) => apiClient.get("/inventory", { params }).then((r) => r.data),
  sync: (plant) => apiClient.post("/inventory/sync", null, { params: { plant } }).then((r) => r.data),
};
