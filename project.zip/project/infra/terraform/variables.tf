variable "project_name" {
  default = "erp-integration"
}

variable "aws_region" {
  default = "us-east-1"
}

variable "environment" {
  default = "production"
}

variable "vpc_cidr" {
  default = "10.0.0.0/16"
}

# Set to the existing VPC ID if the SAP EC2 instance already lives in a VPC
# you want to reuse/peer with, instead of creating a brand-new VPC.
variable "existing_vpc_id" {
  description = "If set, skip VPC creation and deploy into this existing VPC (e.g. the one with SAP)."
  type        = string
  default     = ""
}

variable "sap_ec2_private_ip" {
  description = "Private IP of the SAP EC2 instance running the OData Gateway"
  type        = string
}

variable "sap_odata_port" {
  default = 8000
}

variable "db_instance_class" {
  default = "db.t3.medium"
}

variable "db_name" {
  default = "appdb"
}

variable "db_username" {
  default = "appadmin"
}

variable "container_image_backend" {
  description = "ECR image URI for the FastAPI backend"
  type        = string
}

variable "container_image_frontend" {
  description = "ECR image URI for the React frontend"
  type        = string
}

variable "domain_name" {
  description = "Optional custom domain for the ALB (via Route53/ACM)"
  type        = string
  default     = ""
}
