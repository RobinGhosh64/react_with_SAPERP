# Periodically triggers the SAP -> Postgres sync by hitting the backend's
# internal sync endpoints. Simpler alternative to a separate scheduled task:
# an EventBridge rule invoking a small Lambda that calls the ALB's /api/v1/*/sync
# routes. Swap for an ECS Scheduled Task if you'd rather run it in-cluster.

resource "aws_scheduler_schedule" "sync_orders" {
  name       = "${var.project_name}-sync-orders"
  group_name = "default"

  flexible_time_window {
    mode = "OFF"
  }

  schedule_expression = "rate(15 minutes)"

  target {
    arn      = aws_lambda_function.trigger_sync.arn
    role_arn = aws_iam_role.scheduler_invoke_lambda.arn
    input    = jsonencode({ path = "/api/v1/orders/sync" })
  }
}

resource "aws_scheduler_schedule" "sync_inventory" {
  name       = "${var.project_name}-sync-inventory"
  group_name = "default"

  flexible_time_window {
    mode = "OFF"
  }

  schedule_expression = "rate(15 minutes)"

  target {
    arn      = aws_lambda_function.trigger_sync.arn
    role_arn = aws_iam_role.scheduler_invoke_lambda.arn
    input    = jsonencode({ path = "/api/v1/inventory/sync" })
  }
}

resource "aws_iam_role" "scheduler_invoke_lambda" {
  name = "${var.project_name}-scheduler-invoke-lambda"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "scheduler.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "scheduler_invoke_lambda" {
  role = aws_iam_role.scheduler_invoke_lambda.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "lambda:InvokeFunction"
      Resource = aws_lambda_function.trigger_sync.arn
    }]
  })
}

resource "aws_iam_role" "lambda_exec" {
  name = "${var.project_name}-sync-trigger-lambda"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "lambda_basic" {
  role       = aws_iam_role.lambda_exec.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy_attachment" "lambda_vpc" {
  role       = aws_iam_role.lambda_exec.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole"
}

data "archive_file" "trigger_sync_lambda" {
  type        = "zip"
  output_path = "${path.module}/.build/trigger_sync.zip"
  source {
    content  = <<-EOF
      import os
      import json
      import urllib.request

      ALB_URL = os.environ["BACKEND_URL"]

      def handler(event, context):
          path = event.get("path", "/api/v1/orders/sync")
          req = urllib.request.Request(f"{ALB_URL}{path}", method="POST")
          with urllib.request.urlopen(req, timeout=25) as resp:
              return {"status": resp.status, "body": resp.read().decode()}
    EOF
    filename = "index.py"
  }
}

resource "aws_lambda_function" "trigger_sync" {
  function_name    = "${var.project_name}-trigger-sync"
  role              = aws_iam_role.lambda_exec.arn
  runtime           = "python3.12"
  handler           = "index.handler"
  filename          = data.archive_file.trigger_sync_lambda.output_path
  source_code_hash  = data.archive_file.trigger_sync_lambda.output_base64sha256
  timeout           = 30

  environment {
    variables = {
      BACKEND_URL = "http://${aws_lb.main.dns_name}"
    }
  }
}
