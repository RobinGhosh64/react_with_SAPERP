output "alb_dns_name" {
  value = aws_lb.main.dns_name
}

output "rds_endpoint" {
  value     = aws_db_instance.main.address
  sensitive = false
}

output "ecs_cluster_name" {
  value = aws_ecs_cluster.main.name
}

output "db_credentials_secret_arn" {
  value = aws_secretsmanager_secret.db_credentials.arn
}

output "sap_credentials_secret_arn" {
  description = "Populate this secret manually with the real SAP OData username/password"
  value       = aws_secretsmanager_secret.sap_credentials.arn
}
