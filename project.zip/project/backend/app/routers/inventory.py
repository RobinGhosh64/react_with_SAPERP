from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.inventory import InventoryItem
from app.schemas.inventory import InventoryItemOut
from app.services.sap_client import SAPClient, get_sap_client, SAPODataError
from app.services.sync_service import sync_inventory

router = APIRouter(prefix="/inventory", tags=["inventory"])


@router.get("", response_model=list[InventoryItemOut])
def list_inventory(
    skip: int = 0,
    limit: int = Query(50, le=500),
    plant: str | None = None,
    material_number: str | None = None,
    db: Session = Depends(get_db),
):
    q = db.query(InventoryItem)
    if plant:
        q = q.filter(InventoryItem.plant == plant)
    if material_number:
        q = q.filter(InventoryItem.material_number == material_number)
    return q.offset(skip).limit(limit).all()


@router.post("/sync")
def trigger_sync(
    plant: str | None = None,
    db: Session = Depends(get_db),
    sap: SAPClient = Depends(get_sap_client),
):
    try:
        count = sync_inventory(db, sap, plant=plant)
    except SAPODataError as e:
        raise HTTPException(status_code=502, detail=f"SAP sync failed: {e}")
    return {"synced": count}
