from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload

from app.database import get_db
from app.models.order import Order
from app.schemas.order import OrderOut, OrderCreateRequest
from app.services.sap_client import SAPClient, get_sap_client, SAPODataError
from app.services.sync_service import sync_orders

router = APIRouter(prefix="/orders", tags=["orders"])


@router.get("", response_model=list[OrderOut])
def list_orders(
    skip: int = 0,
    limit: int = Query(50, le=200),
    customer_id: str | None = None,
    db: Session = Depends(get_db),
):
    """Reads from local Postgres (fast) — kept in sync via sync_orders()."""
    q = db.query(Order).options(joinedload(Order.line_items))
    if customer_id:
        q = q.filter(Order.customer_id == customer_id)
    return q.order_by(Order.order_date.desc()).offset(skip).limit(limit).all()


@router.get("/{order_id}", response_model=OrderOut)
def get_order(order_id: str, db: Session = Depends(get_db)):
    order = (
        db.query(Order)
        .options(joinedload(Order.line_items))
        .filter(Order.id == order_id)
        .first()
    )
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@router.post("/sync")
def trigger_sync(
    changed_since: str | None = None,
    db: Session = Depends(get_db),
    sap: SAPClient = Depends(get_sap_client),
):
    """Manually trigger a pull from SAP. In production this also runs on a schedule."""
    try:
        count = sync_orders(db, sap, changed_since=changed_since)
    except SAPODataError as e:
        raise HTTPException(status_code=502, detail=f"SAP sync failed: {e}")
    return {"synced": count}


@router.post("", response_model=dict, status_code=201)
def create_order(
    payload: OrderCreateRequest,
    sap: SAPClient = Depends(get_sap_client),
):
    """Creates the order in SAP first (source of truth), then relies on the
    next sync to mirror it locally."""
    sap_payload = {
        "CustomerId": payload.customer_id,
        "Items": {"results": payload.line_items},
    }
    try:
        result = sap.create_order(sap_payload)
    except SAPODataError as e:
        raise HTTPException(status_code=502, detail=f"Failed to create order in SAP: {e}")
    return {"sap_order_number": result.get("OrderNumber"), "raw": result}
