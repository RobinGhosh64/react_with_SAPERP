import uuid
from datetime import datetime

from sqlalchemy import Column, String, Numeric, DateTime
from sqlalchemy.dialects.postgresql import UUID

from app.database import Base


class InventoryItem(Base):
    __tablename__ = "inventory_items"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    material_number = Column(String(40), unique=True, index=True, nullable=False)  # MATNR
    plant = Column(String(10), index=True, nullable=False)  # WERKS
    description = Column(String(255), nullable=True)
    quantity_on_hand = Column(Numeric(15, 3), nullable=False, default=0)
    quantity_reserved = Column(Numeric(15, 3), nullable=False, default=0)
    unit_of_measure = Column(String(10), nullable=True)
    storage_location = Column(String(10), nullable=True)  # LGORT

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_synced_at = Column(DateTime, nullable=True)

    @property
    def quantity_available(self):
        return (self.quantity_on_hand or 0) - (self.quantity_reserved or 0)
