import uuid
from datetime import datetime

from sqlalchemy import Column, String, Numeric, DateTime, ForeignKey, Integer, Enum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
import enum

from app.database import Base


class OrderStatus(str, enum.Enum):
    OPEN = "OPEN"
    IN_PROGRESS = "IN_PROGRESS"
    SHIPPED = "SHIPPED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class Order(Base):
    __tablename__ = "orders"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    sap_order_number = Column(String(20), unique=True, index=True, nullable=False)  # VBELN
    customer_id = Column(String(20), index=True, nullable=False)  # KUNNR
    customer_name = Column(String(255), nullable=True)
    status = Column(Enum(OrderStatus), default=OrderStatus.OPEN, nullable=False)
    order_date = Column(DateTime, nullable=False)
    total_value = Column(Numeric(15, 2), nullable=True)
    currency = Column(String(5), default="USD")

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_synced_at = Column(DateTime, nullable=True)  # last successful pull from SAP

    line_items = relationship("OrderLineItem", back_populates="order", cascade="all, delete-orphan")


class OrderLineItem(Base):
    __tablename__ = "order_line_items"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    order_id = Column(UUID(as_uuid=True), ForeignKey("orders.id"), nullable=False)
    sap_item_number = Column(String(10), nullable=False)  # POSNR
    material_number = Column(String(40), index=True, nullable=False)  # MATNR
    material_description = Column(String(255), nullable=True)
    quantity = Column(Numeric(15, 3), nullable=False)
    unit_of_measure = Column(String(10), nullable=True)
    unit_price = Column(Numeric(15, 2), nullable=True)

    order = relationship("Order", back_populates="line_items")
