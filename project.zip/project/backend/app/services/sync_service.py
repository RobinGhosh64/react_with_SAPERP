"""
Syncs data from SAP OData into the app's own Postgres tables, so the React
frontend reads from fast local Postgres queries instead of hitting SAP
directly on every page load. Run this via a scheduled job (e.g. ECS
Scheduled Task / EventBridge every N minutes) or trigger manually via an
admin endpoint.
"""
import logging
from datetime import datetime
from decimal import Decimal

from sqlalchemy.orm import Session

from app.models.order import Order, OrderLineItem, OrderStatus
from app.models.inventory import InventoryItem
from app.services.sap_client import SAPClient

logger = logging.getLogger(__name__)

SAP_TO_LOCAL_STATUS = {
    "A": OrderStatus.OPEN,
    "B": OrderStatus.IN_PROGRESS,
    "C": OrderStatus.COMPLETED,
    "X": OrderStatus.CANCELLED,
}


def sync_orders(db: Session, sap: SAPClient, changed_since: str | None = None) -> int:
    sap_orders = sap.get_orders(changed_since=changed_since)
    count = 0
    for sap_order in sap_orders:
        order = db.query(Order).filter_by(sap_order_number=sap_order["OrderNumber"]).first()
        if not order:
            order = Order(sap_order_number=sap_order["OrderNumber"])
            db.add(order)

        order.customer_id = sap_order.get("CustomerId", "")
        order.customer_name = sap_order.get("CustomerName")
        order.status = SAP_TO_LOCAL_STATUS.get(sap_order.get("StatusCode"), OrderStatus.OPEN)
        order.order_date = _parse_sap_date(sap_order.get("OrderDate"))
        order.total_value = Decimal(str(sap_order.get("TotalValue", 0)))
        order.currency = sap_order.get("Currency", "USD")
        order.last_synced_at = datetime.utcnow()

        db.flush()  # ensure order.id is available

        for item in sap_order.get("Items", {}).get("results", []):
            line = (
                db.query(OrderLineItem)
                .filter_by(order_id=order.id, sap_item_number=item["ItemNumber"])
                .first()
            )
            if not line:
                line = OrderLineItem(order_id=order.id, sap_item_number=item["ItemNumber"])
                db.add(line)
            line.material_number = item.get("MaterialNumber", "")
            line.material_description = item.get("MaterialDescription")
            line.quantity = Decimal(str(item.get("Quantity", 0)))
            line.unit_of_measure = item.get("UnitOfMeasure")
            line.unit_price = Decimal(str(item.get("UnitPrice", 0))) if item.get("UnitPrice") else None

        count += 1

    db.commit()
    logger.info("Synced %d orders from SAP", count)
    return count


def sync_inventory(db: Session, sap: SAPClient, plant: str | None = None) -> int:
    sap_items = sap.get_inventory(plant=plant)
    count = 0
    for sap_item in sap_items:
        item = db.query(InventoryItem).filter_by(material_number=sap_item["MaterialNumber"]).first()
        if not item:
            item = InventoryItem(material_number=sap_item["MaterialNumber"])
            db.add(item)

        item.plant = sap_item.get("Plant", "")
        item.description = sap_item.get("Description")
        item.quantity_on_hand = Decimal(str(sap_item.get("QuantityOnHand", 0)))
        item.quantity_reserved = Decimal(str(sap_item.get("QuantityReserved", 0)))
        item.unit_of_measure = sap_item.get("UnitOfMeasure")
        item.storage_location = sap_item.get("StorageLocation")
        item.last_synced_at = datetime.utcnow()

        count += 1

    db.commit()
    logger.info("Synced %d inventory items from SAP", count)
    return count


def _parse_sap_date(sap_date_str: str | None) -> datetime:
    """SAP OData JSON dates often look like '/Date(1699999999000)/'."""
    if not sap_date_str:
        return datetime.utcnow()
    if sap_date_str.startswith("/Date("):
        millis = int(sap_date_str.replace("/Date(", "").replace(")/", ""))
        return datetime.utcfromtimestamp(millis / 1000)
    try:
        return datetime.fromisoformat(sap_date_str)
    except ValueError:
        return datetime.utcnow()
