"""
Central app configuration, loaded from environment variables.
In AWS, these should come from ECS task definition env vars / Secrets Manager,
NOT from a committed .env file.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- App ---
    APP_NAME: str = "erp-integration-api"
    ENV: str = "development"
    API_PREFIX: str = "/api/v1"

    # --- Postgres (RDS) ---
    DATABASE_URL: str = "postgresql+psycopg2://postgres:postgres@localhost:5432/appdb"

    # --- SAP OData ---
    # Base URL of the SAP Gateway OData service running on the EC2 instance,
    # e.g. http://10.0.4.15:8000/sap/opu/odata/sap/ZORDER_INVENTORY_SRV
    SAP_ODATA_BASE_URL: str = "http://CHANGE_ME:8000/sap/opu/odata/sap/ZORDER_INVENTORY_SRV"
    SAP_ODATA_USERNAME: str = "CHANGE_ME"
    SAP_ODATA_PASSWORD: str = "CHANGE_ME"
    SAP_ODATA_TIMEOUT_SECONDS: int = 30
    SAP_ODATA_VERIFY_SSL: bool = True

    # --- Auth (for the app's own API, not SAP) ---
    JWT_SECRET: str = "CHANGE_ME_IN_SECRETS_MANAGER"
    JWT_ALGORITHM: str = "HS256"

    # --- CORS ---
    CORS_ORIGINS: list[str] = ["http://localhost:5173"]


settings = Settings()
