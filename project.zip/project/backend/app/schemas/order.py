import uuid
from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict

from app.models.order import OrderStatus


class OrderLineItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    sap_item_number: str
    material_number: str
    material_description: str | None
    quantity: Decimal
    unit_of_measure: str | None
    unit_price: Decimal | None


class OrderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    sap_order_number: str
    customer_id: str
    customer_name: str | None
    status: OrderStatus
    order_date: datetime
    total_value: Decimal | None
    currency: str
    last_synced_at: datetime | None
    line_items: list[OrderLineItemOut] = []


class OrderCreateRequest(BaseModel):
    """Payload for creating a new order — pushed to SAP, then mirrored locally."""
    customer_id: str
    line_items: list[dict]  # [{material_number, quantity, unit_of_measure}, ...]
