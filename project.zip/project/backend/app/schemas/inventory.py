import uuid
from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict


class InventoryItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    material_number: str
    plant: str
    description: str | None
    quantity_on_hand: Decimal
    quantity_reserved: Decimal
    unit_of_measure: str | None
    storage_location: str | None
    last_synced_at: datetime | None

    @property
    def quantity_available(self) -> Decimal:
        return (self.quantity_on_hand or 0) - (self.quantity_reserved or 0)
