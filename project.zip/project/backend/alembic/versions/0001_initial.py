"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-08-09
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    order_status = postgresql.ENUM(
        "OPEN", "IN_PROGRESS", "SHIPPED", "COMPLETED", "CANCELLED", name="orderstatus"
    )
    order_status.create(op.get_bind())

    op.create_table(
        "orders",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("sap_order_number", sa.String(20), nullable=False, unique=True),
        sa.Column("customer_id", sa.String(20), nullable=False),
        sa.Column("customer_name", sa.String(255)),
        sa.Column("status", order_status, nullable=False),
        sa.Column("order_date", sa.DateTime, nullable=False),
        sa.Column("total_value", sa.Numeric(15, 2)),
        sa.Column("currency", sa.String(5), server_default="USD"),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("last_synced_at", sa.DateTime),
    )
    op.create_index("ix_orders_sap_order_number", "orders", ["sap_order_number"])
    op.create_index("ix_orders_customer_id", "orders", ["customer_id"])

    op.create_table(
        "order_line_items",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("order_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("orders.id"), nullable=False),
        sa.Column("sap_item_number", sa.String(10), nullable=False),
        sa.Column("material_number", sa.String(40), nullable=False),
        sa.Column("material_description", sa.String(255)),
        sa.Column("quantity", sa.Numeric(15, 3), nullable=False),
        sa.Column("unit_of_measure", sa.String(10)),
        sa.Column("unit_price", sa.Numeric(15, 2)),
    )
    op.create_index("ix_order_line_items_material_number", "order_line_items", ["material_number"])

    op.create_table(
        "inventory_items",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("material_number", sa.String(40), nullable=False, unique=True),
        sa.Column("plant", sa.String(10), nullable=False),
        sa.Column("description", sa.String(255)),
        sa.Column("quantity_on_hand", sa.Numeric(15, 3), nullable=False, server_default="0"),
        sa.Column("quantity_reserved", sa.Numeric(15, 3), nullable=False, server_default="0"),
        sa.Column("unit_of_measure", sa.String(10)),
        sa.Column("storage_location", sa.String(10)),
        sa.Column("created_at", sa.DateTime),
        sa.Column("updated_at", sa.DateTime),
        sa.Column("last_synced_at", sa.DateTime),
    )
    op.create_index("ix_inventory_items_material_number", "inventory_items", ["material_number"])
    op.create_index("ix_inventory_items_plant", "inventory_items", ["plant"])


def downgrade():
    op.drop_table("order_line_items")
    op.drop_table("orders")
    op.drop_table("inventory_items")
    postgresql.ENUM(name="orderstatus").drop(op.get_bind())
