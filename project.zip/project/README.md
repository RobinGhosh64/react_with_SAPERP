# Order & Inventory Portal — SAP Integration

Full-stack app: **React** (frontend) + **FastAPI** (backend) + **Postgres/RDS**,
integrated with **SAP Order Processing & Inventory** via SAP OData (SAP Gateway),
where SAP runs on an EC2 instance in the client's AWS environment.

## Architecture

```
Internet → ALB → [React/nginx container]   (public-facing UI)
                → [FastAPI container]  ──►  RDS Postgres      (app's own data store)
                                       ──►  SAP EC2 (OData Gateway, private IP)
```

- The frontend never talks to SAP directly — only through the FastAPI backend.
- FastAPI pulls orders/inventory from SAP OData and mirrors them into Postgres
  (`app/services/sync_service.py`), so the UI reads from fast local queries.
- A scheduled job (EventBridge → Lambda → `/api/v1/*/sync`) keeps Postgres fresh
  every 15 minutes; you can also trigger sync manually from the UI.
- Order **creation** writes straight to SAP (source of truth) via OData POST,
  then the next sync mirrors it back locally.
- Security groups restrict the backend to reach only RDS (5432) and the SAP
  EC2 instance's OData port — nothing else outbound, and SAP is never exposed
  to the internet.

## Before you deploy — things only you can fill in

1. **SAP OData service details** (`backend/app/core/config.py` / task def env vars):
   - Real `SAP_ODATA_BASE_URL` path (the entity set names `SalesOrderSet` /
     `MaterialStockSet` in `sap_client.py` and `sync_service.py` are placeholders —
     replace with your actual SAP Gateway service's entity sets and field names).
   - SAP OData service user credentials (put these in Secrets Manager, not in code).
2. **Networking to SAP EC2** (`infra/terraform/variables.tf`):
   - `sap_ec2_private_ip` — the private IP of the SAP EC2 instance.
   - If SAP lives in a different VPC than the app, either set `existing_vpc_id`
     to deploy into the same VPC, or set up VPC peering / Transit Gateway and
     update the security group CIDR in `security_groups.tf`.
   - Add an inbound rule on the **SAP EC2 instance's own security group**
     allowing the backend's security group on the OData port — Terraform here
     only manages the app side.
3. **Container images**: build and push to ECR, then set `container_image_backend`
   / `container_image_frontend` in tfvars.

## Local development

```bash
# Backend
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in local DB + SAP dev system details
alembic upgrade head
uvicorn app.main:app --reload

# Frontend
cd frontend
npm install
npm run dev
```

## Deploying to AWS

```bash
# 1. Build & push images
aws ecr get-login-password | docker login --username AWS --password-stdin <account>.dkr.ecr.<region>.amazonaws.com
docker build -t <ecr-repo-backend>:latest backend/ && docker push <ecr-repo-backend>:latest
docker build -t <ecr-repo-frontend>:latest frontend/ && docker push <ecr-repo-frontend>:latest

# 2. Provision infrastructure
cd infra/terraform
terraform init
terraform plan -var="sap_ec2_private_ip=10.0.x.x" \
                -var="container_image_backend=<ecr-uri>:latest" \
                -var="container_image_frontend=<ecr-uri>:latest"
terraform apply

# 3. Populate the real SAP credentials (don't put these in tfvars)
aws secretsmanager put-secret-value \
  --secret-id erp-integration/sap-odata-credentials \
  --secret-string '{"username":"SAP_USER","password":"SAP_PASSWORD"}'

# 4. Run the initial DB migration (one-off task against the ECS cluster, or run
#    alembic upgrade head from a bastion/VPN-connected machine pointed at RDS)
```

## Repo layout

```
backend/          FastAPI app, SQLAlchemy models, Alembic migrations, SAP client
frontend/         React (Vite) app
infra/terraform/  VPC, RDS, ECS Fargate, ALB, security groups, scheduled sync
```

## Known placeholders to replace before production use

- Entity set names / field mappings in `sap_client.py` and `sync_service.py`
  (`SalesOrderSet`, `MaterialStockSet`, field names like `OrderNumber`) —
  these must match your actual SAP OData service metadata (`$metadata` endpoint).
- Authentication on the app's own API (currently open) — wire up your identity
  provider (Cognito, Okta, client SSO) and enforce it in FastAPI dependencies.
- HTTPS on the ALB (commented-out listener in `alb.tf`) — needs an ACM cert.
- Terraform remote state backend (commented out in `main.tf`).
